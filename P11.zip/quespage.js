function score_calc(form)
      {
        var str = form.word.value;
        var len = str.length;
        var score = 0;
        if(document.getElementById("Q1A").checked == true)
        {
            score = score+1;
        }


      }